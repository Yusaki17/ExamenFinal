function abrirModalEditar(id, venta, clienteId, marcaId, productoId, tiempoId) {
  document.getElementById('editId').value = id;
  document.getElementById('editTotal').value = venta; // <--- ESTE CAMPO
  document.getElementById('editClienteId').value = clienteId;
  document.getElementById('editMarcaId').value = marcaId;
  document.getElementById('editProductoId').value = productoId;
  document.getElementById('editTiempoId').value = tiempoId;

  var modal = new bootstrap.Modal(document.getElementById('modalEditar'));
  modal.show();
}