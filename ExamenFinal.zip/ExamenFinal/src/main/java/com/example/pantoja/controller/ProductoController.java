package com.example.pantoja.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.pantoja.entity.Producto;
import com.example.pantoja.service.ProductoService;

@Controller
@RequestMapping("/productos")
public class ProductoController {
	
	private final ProductoService productoService;

	public ProductoController(ProductoService productoService) {
		this.productoService = productoService;
	}
	
	@GetMapping
	public String listar(Model model) {
		model.addAttribute("productos", productoService.readAll());
		model.addAttribute("producto", new Producto()); // útil si usas modal
		return "pro"; // o "productos/index" según tu archivo de vista
	}
	
	@GetMapping("/nueva")
	public String nueva(Model model) {
		model.addAttribute("producto", new Producto());
		return "productos/form";
	}
	
	@PostMapping("/guardar")
	public String guardar(Producto producto) {
		if (producto.getIdProducto() != null) {
			productoService.update(producto);
		} else {
			productoService.create(producto);
		}
		return "redirect:/productos";
	}
	
	@GetMapping("/editar/{idProducto}")
	public String editar(@PathVariable("idProducto") Long idProducto, Model model) {
		model.addAttribute("producto", productoService.read(idProducto));
		return "productos/form";
	}
	
	@GetMapping("/eliminar/{idProducto}")
	public String eliminar(@PathVariable("idProducto") Long idProducto) {
		productoService.delete(idProducto);
		return "redirect:/productos";
	}
}
