package com.example.pantoja.generic;

import java.util.List;

public interface IGeneric<T> {
	
	int create(T t);
	int update(T t);
	int delete(Long id);
	T read(Long id);
	List<T> readAll();

}
