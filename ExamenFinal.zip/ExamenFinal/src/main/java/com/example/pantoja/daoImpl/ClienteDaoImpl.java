package com.example.pantoja.daoImpl;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.pantoja.dao.ClienteDao;
import com.example.pantoja.entity.Cliente;
@Repository
public class ClienteDaoImpl implements ClienteDao{
	
	private final JdbcTemplate jdbc;
	
	@SuppressWarnings("unused")
	private Cliente mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
	    Cliente c = new Cliente();
	    c.setIdCliente(rs.getLong("ID_CLIENTE"));    
	    c.setCliente(rs.getString("CLIENTE"));
	         
	    return c;
	}

	public ClienteDaoImpl(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public int create(Cliente t) {
		// TODO Auto-generated method stub
		return jdbc.update("INSERT INTO CLIENTES (CLIENTE) VALUES (?)", t.getCliente());
	}

	@Override
	public int update(Cliente t) {
		// TODO Auto-generated method stub
		return jdbc.update("UPDATE CLIENTES SET CLIENTE = ? WHERE ID_CLIENTE = ?", t.getCliente());
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return jdbc.update("DELETE FROM CLIENTES WHERE ID_CLIENTE = ?", id);
	}

	@Override
	public Cliente read(Long id) {
		// TODO Auto-generated method stub
		return jdbc.queryForObject("SELECT * FROM CLIENTES WHERE ID_CLIENTE = ?", this::mapRow, id);
	}

	@Override
	public List<Cliente> readAll() {
		// TODO Auto-generated method stub
		return jdbc.query("SELECT * FROM CLIENTES", this::mapRow);
	}

}
