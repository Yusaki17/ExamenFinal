package com.example.pantoja.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pantoja.dao.VentaDao;
import com.example.pantoja.entity.Venta;
import com.example.pantoja.service.VentaService;
@Service
public class VentaServiceImpl implements VentaService {
	
	private final VentaDao ventaDao;

    public VentaServiceImpl(VentaDao ventaDao) {
        this.ventaDao = ventaDao;
    }

	@Override
	public int create(Venta t) {
		// TODO Auto-generated method stub
		return ventaDao.create(t);
	}

	@Override
	public int update(Venta t) {
		// TODO Auto-generated method stub
		return ventaDao.update(t);
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return ventaDao.delete(id);
	}

	@Override
	public Venta read(Long id) {
		// TODO Auto-generated method stub
		return ventaDao.read(id);
	}

	@Override
	public List<Venta> readAll() {
		// TODO Auto-generated method stub
		return ventaDao.readAll();
	}

}
