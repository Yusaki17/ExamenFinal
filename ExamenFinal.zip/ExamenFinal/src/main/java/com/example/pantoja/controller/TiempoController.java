package com.example.pantoja.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.pantoja.entity.Tiempo;
import com.example.pantoja.service.TiempoService;

@Controller
@RequestMapping("/tiempos")
public class TiempoController {

    private final TiempoService tiempoService;

    public TiempoController(TiempoService tiempoService) {
        this.tiempoService = tiempoService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("tiempos", tiempoService.readAll());
        model.addAttribute("tiempo", new Tiempo()); // útil para usar modal
        return "tie"; // o "tiempos/index" si esa es tu vista
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("tiempo", new Tiempo());
        return "tiempos/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Tiempo tiempo) {
        if (tiempo.getIdTiempo() != null) {
            tiempoService.update(tiempo);
        } else {
            tiempoService.create(tiempo);
        }
        return "redirect:/tiempos";
    }

    @GetMapping("/editar/{idTiempo}")
    public String editar(@PathVariable("idTiempo") Long idTiempo, Model model) {
        model.addAttribute("tiempo", tiempoService.read(idTiempo));
        return "tiempos/form";
    }

    @GetMapping("/eliminar/{idTiempo}")
    public String eliminar(@PathVariable("idTiempo") Long idTiempo) {
        tiempoService.delete(idTiempo);
        return "redirect:/tiempos";
    }
}
