package com.example.pantoja.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Producto {
	
	private Long idProducto;
	private String producto;
	private String clase;

}
