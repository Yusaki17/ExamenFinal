package com.example.pantoja.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pantoja.dao.MarcaDao;
import com.example.pantoja.entity.Marca;
import com.example.pantoja.service.MarcaService;
@Service
public class MarcaServiceImpl implements MarcaService {
	
private final MarcaDao marcaDao;
	
	public MarcaServiceImpl(MarcaDao marcaDao) {
		this.marcaDao = marcaDao;
	}

	@Override
	public int create(Marca t) {
		// TODO Auto-generated method stub
		return marcaDao.create(t);
	}

	@Override
	public int update(Marca t) {
		// TODO Auto-generated method stub
		return marcaDao.update(t);
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return marcaDao.delete(id);
	}

	@Override
	public Marca read(Long id) {
		// TODO Auto-generated method stub
		return marcaDao.read(id);
	}

	@Override
	public List<Marca> readAll() {
		// TODO Auto-generated method stub
		return marcaDao.readAll();
	}

}
