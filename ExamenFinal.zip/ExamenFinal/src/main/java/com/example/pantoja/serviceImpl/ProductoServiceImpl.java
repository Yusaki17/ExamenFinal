package com.example.pantoja.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pantoja.dao.ProductoDao;
import com.example.pantoja.entity.Producto;
import com.example.pantoja.service.ProductoService;
@Service
public class ProductoServiceImpl implements ProductoService {
	
	private final ProductoDao productoDao;

    public ProductoServiceImpl(ProductoDao productoDao) {
        this.productoDao = productoDao;
    }

	@Override
	public int create(Producto t) {
		// TODO Auto-generated method stub
		return productoDao.create(t);
	}

	@Override
	public int update(Producto t) {
		// TODO Auto-generated method stub
		return productoDao.update(t);
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return productoDao.delete(id);
	}

	@Override
	public Producto read(Long id) {
		// TODO Auto-generated method stub
		return productoDao.read(id);
	}

	@Override
	public List<Producto> readAll() {
		// TODO Auto-generated method stub
		return productoDao.readAll();
	}

}
