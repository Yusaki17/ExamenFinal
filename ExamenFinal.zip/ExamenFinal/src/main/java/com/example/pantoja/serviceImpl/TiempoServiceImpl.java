package com.example.pantoja.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pantoja.dao.TiempoDao;
import com.example.pantoja.entity.Tiempo;
import com.example.pantoja.service.TiempoService;
@Service
public class TiempoServiceImpl implements TiempoService {
	
	private final TiempoDao tiempoDao;

    public TiempoServiceImpl(TiempoDao tiempoDao) {
        this.tiempoDao = tiempoDao;
    }

	@Override
	public int create(Tiempo t) {
		// TODO Auto-generated method stub
		 return tiempoDao.create(t);
	}

	@Override
	public int update(Tiempo t) {
		// TODO Auto-generated method stub
		return tiempoDao.update(t);
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return tiempoDao.delete(id);
	}

	@Override
	public Tiempo read(Long id) {
		// TODO Auto-generated method stub
		return tiempoDao.read(id);
	}

	@Override
	public List<Tiempo> readAll() {
		// TODO Auto-generated method stub
		return tiempoDao.readAll();
	}

}
