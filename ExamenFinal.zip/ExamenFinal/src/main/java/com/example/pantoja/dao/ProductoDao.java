package com.example.pantoja.dao;

import com.example.pantoja.entity.Producto;
import com.example.pantoja.generic.IGeneric;

public interface ProductoDao extends IGeneric<Producto> {

}
