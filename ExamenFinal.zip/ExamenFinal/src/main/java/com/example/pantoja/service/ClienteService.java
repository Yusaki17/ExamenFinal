package com.example.pantoja.service;

import com.example.pantoja.entity.Cliente;
import com.example.pantoja.generic.IGeneric;

public interface ClienteService extends IGeneric<Cliente> {

}
