package com.example.pantoja.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.pantoja.entity.Venta;
import com.example.pantoja.service.ClienteService;
import com.example.pantoja.service.MarcaService;
import com.example.pantoja.service.ProductoService;
import com.example.pantoja.service.TiempoService;
import com.example.pantoja.service.VentaService;

@Controller
@RequestMapping("/ventas")
public class VentaController {

	private final VentaService ventaService;
	private final ClienteService clienteService;
	private final MarcaService marcaService;
	private final ProductoService productoService;
	private final TiempoService tiempoService;

	public VentaController(VentaService ventaService, ClienteService clienteService, MarcaService marcaService, ProductoService productoService, TiempoService tiempoService) {
		this.ventaService = ventaService;
		this.clienteService = clienteService;
		this.marcaService = marcaService;
		this.productoService = productoService;
		this.tiempoService = tiempoService;
	}

	@GetMapping
	public String listar(Model model) {
		model.addAttribute("ventas", ventaService.readAll());
		model.addAttribute("venta", new Venta());
		model.addAttribute("clientes", clienteService.readAll());
		model.addAttribute("marcas", marcaService.readAll());
		model.addAttribute("productos", productoService.readAll());
		model.addAttribute("tiempos", tiempoService.readAll());
		return "ven";
	}

	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Venta venta) {
		if (venta.getIdVenta() == null) {
			ventaService.create(venta);
		} else {
			ventaService.update(venta);
		}
		return "redirect:/ventas";
	}

	@GetMapping("/editar/{idVenta}")
	public String editar(@PathVariable("idVenta") Long idVenta, Model model) {
		model.addAttribute("venta", ventaService.read(idVenta));
		model.addAttribute("ventas", ventaService.readAll());
		model.addAttribute("clientes", clienteService.readAll());
		model.addAttribute("marcas", marcaService.readAll());
		model.addAttribute("productos", productoService.readAll());
		model.addAttribute("tiempos", tiempoService.readAll());
		return "ven";
	}

	@GetMapping("/eliminar/{idVenta}")
	public String eliminar(@PathVariable("idVenta") Long idVenta) {
		ventaService.delete(idVenta);
		return "redirect:/ventas";
	}
}
