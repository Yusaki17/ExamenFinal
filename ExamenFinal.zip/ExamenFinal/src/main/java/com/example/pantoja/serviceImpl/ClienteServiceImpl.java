package com.example.pantoja.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pantoja.dao.ClienteDao;
import com.example.pantoja.entity.Cliente;
import com.example.pantoja.service.ClienteService;
@Service
public class ClienteServiceImpl implements ClienteService {
	
	private final ClienteDao clienteDao;
	
	public ClienteServiceImpl(ClienteDao clienteDao) {
		this.clienteDao = clienteDao;
	}
	

	@Override
	public int create(Cliente t) {
		// TODO Auto-generated method stub
		return clienteDao.create(t);
	}

	@Override
	public int update(Cliente t) {
		// TODO Auto-generated method stub
		return clienteDao.update(t);
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return clienteDao.delete(id);
	}

	@Override
	public Cliente read(Long id) {
		// TODO Auto-generated method stub
		return clienteDao.read(id);
	}

	@Override
	public List<Cliente> readAll() {
		// TODO Auto-generated method stub
		return clienteDao.readAll();
	}

}
