package com.example.pantoja.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.pantoja.entity.Cliente;
import com.example.pantoja.service.ClienteService;

@Controller
@RequestMapping("/clientes")
public class ClienteController {
	
	private final ClienteService clienteService;
	
	public ClienteController(ClienteService clienteService) {
		
		this.clienteService = clienteService;
	}
	
	@GetMapping("/nueva")
    public String nueva(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "clientes/form";
    }
	
	@PostMapping("/guardar")
    public String guardar(Cliente cliente) {
        if (cliente.getIdCliente() != null) {
        	clienteService.update(cliente);
        } else {
        	clienteService.create(cliente);
        }
        return "redirect:/clientes";
    }
	
	@GetMapping("/editar/{idCliente}")
	public String editar(@PathVariable("idCliente") Long idCliente, Model model) {
	    model.addAttribute("cliente", clienteService.read(idCliente));
	    return "clientes/form";
	}

	@GetMapping("/eliminar/{idCliente}")
	public String eliminar(@PathVariable("idCliente") Long idCliente) {
	    clienteService.delete(idCliente);
	    return "redirect:/clientes";
	}


}
