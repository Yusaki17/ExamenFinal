package com.example.pantoja.service;

import com.example.pantoja.entity.Producto;
import com.example.pantoja.generic.IGeneric;

public interface ProductoService extends IGeneric<Producto> {

}
