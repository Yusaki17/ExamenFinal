package com.example.pantoja.dao;

import com.example.pantoja.entity.Marca;
import com.example.pantoja.generic.IGeneric;

public interface MarcaDao  extends IGeneric<Marca>{

}
