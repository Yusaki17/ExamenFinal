package com.example.pantoja.daoImpl;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.pantoja.dao.ProductoDao;
import com.example.pantoja.entity.Producto;
@Repository
public class ProductoDaoImpl implements ProductoDao{
	
private final JdbcTemplate jdbc;
	
	@SuppressWarnings("unused")
	private Producto mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
	    Producto p = new Producto();
	    p.setIdProducto(rs.getLong("ID_PRODUCTO"));    
	    p.setProducto(rs.getString("PRODUCTO"));
	    p.setClase(rs.getString("CLASE"));
	         
	    return p;
	}

	public ProductoDaoImpl(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public int create(Producto t) {
		// TODO Auto-generated method stub
		return jdbc.update("INSERT INTO PRODUCTOS (PRODUCTO, CLASE) VALUES (?, ?)", t.getProducto());
	}

	@Override
	public int update(Producto t) {
		// TODO Auto-generated method stub
		return jdbc.update("UPDATE PRODUCTOS SET PRODUCTO = ?, CLASE = ? WHERE ID_PRODUCTO = ?", t.getProducto(), t.getClase());
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return jdbc.update("DELETE FROM PRODUCTOS WHERE ID_PRODUCTO = ?", id);
	}

	@Override
	public Producto read(Long id) {
		// TODO Auto-generated method stub
		return jdbc.queryForObject("SELECT * FROM PRODUCTOS WHERE ID_PRODUCTO = ?", this::mapRow, id);
	}

	@Override
	public List<Producto> readAll() {
		// TODO Auto-generated method stub
		return jdbc.query("SELECT * FROM PRODUCTOS", this::mapRow);
	}

}
