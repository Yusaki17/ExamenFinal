package com.example.pantoja.daoImpl;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.pantoja.dao.VentaDao;
import com.example.pantoja.entity.Venta;
@Repository
public class VentaDaoImpl implements VentaDao {
private final JdbcTemplate jdbc;
	
	@SuppressWarnings("unused")
	private Venta mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
	    Venta v = new Venta();
	    v.setIdVenta(rs.getLong("ID_VENTA"));    
	    v.setIdMarca(rs.getLong("ID_MARCA"));
	    v.setIdTiempo(rs.getLong("ID_TIEMPO"));
	    v.setIdProducto(rs.getLong("ID_PRODUCTO"));
	    v.setIdCliente(rs.getLong("ID_CLIENTE"));
	    v.setVenta(rs.getDouble("VENTA"));
	         
	    return v;
	}

	public VentaDaoImpl(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	@Override
	public int create(Venta t) {
		// TODO Auto-generated method stub
		return jdbc.update(
				  "INSERT INTO VENTAS (ID_MARCA, ID_TIEMPO, ID_PRODUCTO, ID_CLIENTE, VENTA) VALUES (?, ?, ?, ?, ?)",
				  t.getIdMarca(), t.getIdTiempo(), t.getIdProducto(), t.getIdCliente(), t.getVenta());

	}

	@Override
	public int update(Venta t) {
		// TODO Auto-generated method stub
		return jdbc.update("UPDATE VENTAS SET ID_MARCA = ?, ID_TIEMPO = ?, ID_PRODUCTO = ?, ID_CLIENTE = ?, VENTA = ? WHERE ID_VENTA = ?", 
                t.getIdMarca(), t.getIdTiempo(), t.getIdProducto(), t.getIdCliente(), t.getVenta(), t.getIdVenta());

	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return jdbc.update("DELETE FROM VENTAS WHERE ID_VENTA = ?", id);
	}

	@Override
	public Venta read(Long id) {
		// TODO Auto-generated method stub
		return jdbc.queryForObject("SELECT * FROM VENTAS WHERE ID_VENTA = ?", this::mapRow, id);
	}

	@Override
	public List<Venta> readAll() {
		// TODO Auto-generated method stub
		return jdbc.query("SELECT * FROM VENTAS", this::mapRow);
	}

}

