package com.example.pantoja.service;

import com.example.pantoja.entity.Marca;
import com.example.pantoja.generic.IGeneric;

public interface MarcaService extends IGeneric<Marca>{

}
