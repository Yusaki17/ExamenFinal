package com.example.pantoja.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.pantoja.entity.Marca;
import com.example.pantoja.service.MarcaService;

@Controller
@RequestMapping("/marcas")
public class MarcaController {
	
	private final MarcaService marcaService;
	
	public MarcaController(MarcaService marcaService) {
		this.marcaService = marcaService;
	}

	@GetMapping
	public String listar(Model model) {
		model.addAttribute("marcas", marcaService.readAll());
		model.addAttribute("marca", new Marca()); // si usas modal
		return "mar"; // o "marcas/index" si esa es tu vista
	}

	@GetMapping("/nueva")
	public String nueva(Model model) {
		model.addAttribute("marca", new Marca());
		return "marcas/form";
	}

	@PostMapping("/guardar")
	public String guardar(Marca marca) {
		if (marca.getIdMarca() != null) {
			marcaService.update(marca);
		} else {
			marcaService.create(marca);
		}
		return "redirect:/marcas";
	}

	@GetMapping("/editar/{idMarca}")
	public String editar(@PathVariable Long idMarca, Model model) {
		model.addAttribute("marca", marcaService.read(idMarca));
		return "marcas/form";
	}

	@GetMapping("/eliminar/{idMarca}")
	public String eliminar(@PathVariable Long idMarca) {
		marcaService.delete(idMarca);
		return "redirect:/marcas";
	}
}
