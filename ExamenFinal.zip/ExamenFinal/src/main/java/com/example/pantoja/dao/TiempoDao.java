package com.example.pantoja.dao;

import com.example.pantoja.entity.Tiempo;
import com.example.pantoja.generic.IGeneric;

public interface TiempoDao extends IGeneric<Tiempo> {

}
