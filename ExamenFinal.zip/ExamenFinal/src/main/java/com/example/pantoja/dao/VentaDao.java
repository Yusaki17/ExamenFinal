package com.example.pantoja.dao;

import com.example.pantoja.entity.Venta;
import com.example.pantoja.generic.IGeneric;

public interface VentaDao extends IGeneric<Venta> {

}
