package com.example.pantoja.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Venta {
	private Long idVenta;
    private Long idMarca;
    private Long idTiempo;
    private Long idProducto;
    private Long idCliente;
    private double venta;
    
    
    
    
}
