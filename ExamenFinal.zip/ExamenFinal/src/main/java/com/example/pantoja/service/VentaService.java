package com.example.pantoja.service;

import com.example.pantoja.entity.Venta;
import com.example.pantoja.generic.IGeneric;

public interface VentaService extends IGeneric<Venta> {

}
