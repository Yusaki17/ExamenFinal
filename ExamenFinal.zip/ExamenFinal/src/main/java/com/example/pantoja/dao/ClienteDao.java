package com.example.pantoja.dao;

import com.example.pantoja.entity.Cliente;
import com.example.pantoja.generic.IGeneric;

public interface ClienteDao extends IGeneric<Cliente> {

}
