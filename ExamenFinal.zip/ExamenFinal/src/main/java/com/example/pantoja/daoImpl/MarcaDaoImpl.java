package com.example.pantoja.daoImpl;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.pantoja.dao.MarcaDao;
import com.example.pantoja.entity.Marca;

@Repository
public class MarcaDaoImpl implements MarcaDao {
	
	private final JdbcTemplate jdbc;
	
	@SuppressWarnings("unused")
	private Marca mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
	    Marca m = new Marca();
	    m.setIdMarca(rs.getLong("ID_MARCA"));    
	    m.setMarca(rs.getString("MARCA"));
	         
	    return m;
	}

	public MarcaDaoImpl(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public int create(Marca t) {
		// TODO Auto-generated method stub
		return jdbc.update("INSERT INTO MARCAS (MARCA) VALUES (?)", t.getMarca());
	}

	@Override
	public int update(Marca t) {
		// TODO Auto-generated method stub
		return jdbc.update("UPDATE MARCAS SET MARCA = ? WHERE ID_MARCA", t.getMarca());
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return jdbc.update("DELETE FROM MARCAS WHERE ID_MARCA = ?", id);
	}

	@Override
	public Marca read(Long id) {
		// TODO Auto-generated method stub
		return jdbc.queryForObject("SELECT * FROM MARCAS WHERE ID_MARCA = ?", this::mapRow, id);
	}

	@Override
	public List<Marca> readAll() {
		// TODO Auto-generated method stub
		return jdbc.query("SELECT * FROM MARCAS", this::mapRow);
	}

}
