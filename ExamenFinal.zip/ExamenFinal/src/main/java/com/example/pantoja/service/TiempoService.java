package com.example.pantoja.service;

import com.example.pantoja.entity.Tiempo;
import com.example.pantoja.generic.IGeneric;

public interface TiempoService extends IGeneric<Tiempo>{

}
