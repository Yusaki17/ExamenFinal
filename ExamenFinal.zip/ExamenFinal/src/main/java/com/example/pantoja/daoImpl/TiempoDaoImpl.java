package com.example.pantoja.daoImpl;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.pantoja.dao.TiempoDao;
import com.example.pantoja.entity.Tiempo;
@Repository
public class TiempoDaoImpl implements TiempoDao{
	
private final JdbcTemplate jdbc;
	
	@SuppressWarnings("unused")
	private Tiempo mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
	    Tiempo t = new Tiempo();
	    t.setIdTiempo(rs.getLong("ID_TIEMPO"));    
	    t.setAño(rs.getInt("AÑO"));
	         
	    return t;
	}

	public TiempoDaoImpl(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public int create(Tiempo t) {
		// TODO Auto-generated method stub
		return jdbc.update("INSERT INTO TIEMPO (AÑO) VALUES (?)", t.getAño());
	}

	@Override
	public int update(Tiempo t) {
		// TODO Auto-generated method stub
		return jdbc.update("UPDATE TIEMPO SET AÑO = ? WHERE ID_TIEMPO", t.getAño());
	}

	@Override
	public int delete(Long id) {
		// TODO Auto-generated method stub
		return jdbc.update("DELETE FROM TIEMPO WHERE ID_TIEMPO = ?", id);
	}

	@Override
	public Tiempo read(Long id) {
		// TODO Auto-generated method stub
		return jdbc.queryForObject("SELECT * FROM TIEMPO WHERE ID_TIEMPO = ?", this::mapRow, id);
	}

	@Override
	public List<Tiempo> readAll() {
		// TODO Auto-generated method stub
		return jdbc.query("SELECT * FROM TIEMPO", this::mapRow);
	}

}
